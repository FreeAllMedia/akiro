if(!global._babelPolyfill) {
	require("babel-polyfill");
}

module.exports = require("./es5/lib/incognito.js");
